export const STORAGE_KEYS = {
  AUTH_STATE: "authState",
  NIP46_CLIENT_KEY: "nip46ClientKey",
  NSEC_ENCRYPTED: "nsecEncrypted",
  SETTINGS: "settings",
  RELAYS: "relays",
  OVERLAY_NUDGE_DISMISSED: "overlayNudgeDismissed",
  ONBOARDING_SHOWN: "onboardingShown",
  CAST_COUNT: "castCount"
};
export const DEFAULT_RELAYS = [
  "wss://relay.damus.io",
  "wss://nos.lol",
  "wss://relay.snort.social"
  //not working 'wss://relay.nostr.band',
];
