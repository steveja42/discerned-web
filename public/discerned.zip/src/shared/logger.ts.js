const REMOTE_LOGGING = true;
const LEVELS = ["log", "warn", "error", "info", "debug"];
const originals = {};
function serializeArg(arg) {
  if (arg instanceof Error) {
    return arg.stack ? `[Error] ${arg.stack}` : `[Error] ${arg.message}`;
  }
  if (typeof arg === "object" && arg !== null) {
    try {
      return JSON.stringify(arg);
    } catch {
      return String(arg);
    }
  }
  return String(arg);
}
function forwardToActiveTab(source, level, args) {
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (tabId === void 0) return;
      chrome.tabs.sendMessage(tabId, {
        type: "LOG_RELAY",
        source,
        level,
        serialized: args.map(serializeArg)
      }).catch(() => {
      });
    });
  } catch {
  }
}
export function initLogBridge(source) {
  const c = console;
  for (const level of LEVELS) {
    originals[level] = c[level].bind(console);
    if (!REMOTE_LOGGING) continue;
    if (source === "content" || source === "onboarding") {
      const orig = originals[level];
      c[level] = (...args) => orig(`[${source}]`, ...args);
    } else {
      const orig = originals[level];
      c[level] = (...args) => {
        orig(...args);
        forwardToActiveTab(source, level, args);
      };
    }
  }
}
export function relayLog(level, source, serialized) {
  const fn = originals[level] ?? console[level].bind(console);
  fn(`[${source}]`, ...serialized);
}
