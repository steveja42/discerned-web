import { STORAGE_KEYS } from "/src/shared/types.ts.js";
export async function detectAuthState() {
  const stored = await chrome.storage.local.get([STORAGE_KEYS.AUTH_STATE]);
  const saved = stored[STORAGE_KEYS.AUTH_STATE];
  if (saved?.type === "nip46" || saved?.type === "nsec") {
    return saved;
  }
  const hasNIP07 = await checkForNIP07();
  if (hasNIP07) {
    return { type: "pro", hasNIP07: true };
  }
  return { type: "guest" };
}
async function checkForNIP07() {
  return new Promise((resolve) => {
    const handler = (event) => {
      if (event.data?.type === "DISCERNED_NIP07_CHECK_RESPONSE") {
        window.removeEventListener("message", handler);
        clearTimeout(timer);
        resolve(event.data.hasNostr);
      }
    };
    window.addEventListener("message", handler);
    window.postMessage({ type: "DISCERNED_NIP07_CHECK" }, "*");
    const timer = setTimeout(() => {
      window.removeEventListener("message", handler);
      resolve(false);
    }, 1e3);
  });
}
export async function getNIP07PublicKey() {
  return new Promise((resolve) => {
    const handler = (event) => {
      if (event.data?.type === "DISCERNED_NIP07_PUBKEY_RESPONSE") {
        window.removeEventListener("message", handler);
        clearTimeout(timer);
        resolve(event.data.pubkey || null);
      }
    };
    window.addEventListener("message", handler);
    window.postMessage({ type: "DISCERNED_NIP07_PUBKEY" }, "*");
    const timer = setTimeout(() => {
      window.removeEventListener("message", handler);
      resolve(null);
    }, 3e3);
  });
}
export async function signWithNIP07(event) {
  return new Promise((resolve, reject) => {
    const messageId = `sign_${Date.now()}`;
    const handler = (msgEvent) => {
      if (msgEvent.data?.type === "DISCERNED_NIP07_SIGN_RESPONSE" && msgEvent.data.id === messageId) {
        window.removeEventListener("message", handler);
        clearTimeout(timer);
        if (msgEvent.data.error) {
          reject(new Error(msgEvent.data.error));
        } else {
          resolve(msgEvent.data.signed);
        }
      }
    };
    window.addEventListener("message", handler);
    window.postMessage({ type: "DISCERNED_NIP07_SIGN", id: messageId, event }, "*");
    const timer = setTimeout(() => {
      window.removeEventListener("message", handler);
      reject(new Error("NIP-07 signing timeout"));
    }, 1e4);
  });
}
export async function saveAuthState(state) {
  await chrome.storage.local.set({
    [STORAGE_KEYS.AUTH_STATE]: state
  });
}
export async function clearAuthState() {
  await chrome.storage.local.remove([
    STORAGE_KEYS.AUTH_STATE,
    STORAGE_KEYS.NIP46_CLIENT_KEY,
    STORAGE_KEYS.NSEC_ENCRYPTED
  ]);
}
