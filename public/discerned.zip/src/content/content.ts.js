import { captureContext, isCapturablePage } from "/src/content/capture.ts.js";
import { DiscernedOverlay } from "/src/content/overlay.ts.js";
import { detectAuthState, signWithNIP07 } from "/src/shared/nostr/auth.ts.js";
import { STORAGE_KEYS } from "/src/shared/types.ts.js";
import { initLogBridge, relayLog } from "/src/shared/logger.ts.js";
initLogBridge("content");
let currentOverlay = null;
let cachedAuthState = { type: "guest" };
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "ACTIVATE_DISCERNED") {
    handleActivation();
    sendResponse({ success: true });
  } else if (message.type === "SIGN_WITH_NIP07") {
    signWithNIP07(message.event).then((signed) => sendResponse({ signed })).catch((err) => sendResponse({
      error: err instanceof Error ? err.message : "NIP-07 signing failed"
    }));
    return true;
  } else if (message.type === "LOG_RELAY") {
    relayLog(message.level, message.source, message.serialized);
  }
  return true;
});
detectAuthState().then((state) => {
  cachedAuthState = state;
  if (state.type === "pro") {
    chrome.runtime.sendMessage({ type: "NIP07_DETECTED", hasNIP07: true }).catch(() => {
    });
  }
}).catch(() => {
});
async function handleActivation() {
  if (!isCapturablePage()) {
    console.warn("Discerned: Cannot capture on this page");
    return;
  }
  if (currentOverlay) {
    currentOverlay.hide();
  }
  const capture = captureContext();
  let nudgeDismissed = false;
  try {
    const stored = await chrome.storage.local.get(STORAGE_KEYS.OVERLAY_NUDGE_DISMISSED);
    nudgeDismissed = !!stored[STORAGE_KEYS.OVERLAY_NUDGE_DISMISSED];
  } catch {
  }
  let freshAuthState = cachedAuthState;
  try {
    const authRes = await chrome.runtime.sendMessage({ type: "GET_AUTH_STATE" });
    if (authRes?.success && authRes.data) {
      freshAuthState = authRes.data;
      cachedAuthState = freshAuthState;
    }
  } catch {
  }
  currentOverlay = new DiscernedOverlay();
  document.body.appendChild(currentOverlay);
  currentOverlay.show(capture, {
    onClip: (evaluation) => handleClip(capture, evaluation),
    onCast: (evaluation) => handleCast(capture, evaluation)
  }, freshAuthState, nudgeDismissed);
}
function sendToBackground(message) {
  return Promise.race([
    chrome.runtime.sendMessage(message),
    new Promise(
      (_, reject) => setTimeout(() => reject(new Error("Background service worker did not respond")), 3e4)
    )
  ]);
}
async function handleClip(capture, evaluation) {
  try {
    const response = await sendToBackground({ type: "CLIP", data: { capture, evaluation } });
    if (!response.success) {
      throw new Error(response.error);
    }
    console.log("Discerned: Successfully clipped");
  } catch (error) {
    console.error("Discerned: Clip failed", error);
    throw error;
  }
}
async function handleCast(capture, evaluation) {
  try {
    const response = await sendToBackground({ type: "CAST", data: { capture, evaluation } });
    if (!response.success) {
      throw new Error(response.error);
    }
    console.log("Discerned: Successfully cast");
  } catch (error) {
    console.error("Discerned: Cast failed", error);
    showCastErrorToast(error instanceof Error ? error.message : "Broadcast failed");
    throw error;
  }
}
function showCastErrorToast(message) {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;bottom:24px;right:24px;z-index:2147483647;display:block;";
  host.attachShadow({ mode: "closed" }).innerHTML = `
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
      .toast {
        background: #1a1a1a; border: 1px solid #ef4444; border-radius: 8px;
        padding: 12px 16px; max-width: 300px; line-height: 1.4;
        box-shadow: 0 4px 16px rgba(0,0,0,0.6);
        animation: in .25s ease;
      }
      @keyframes in { from { opacity:0; transform:translateY(8px) } to { opacity:1; transform:none } }
      .title { font-size: 13px; font-weight: 600; color: #f87171; margin-bottom: 4px; }
      .body  { font-size: 12px; color: #888; }
    </style>
    <div class="toast">
      <div class="title">📡 Broadcast failed</div>
      <div class="body">${esc(message)}</div>
    </div>
  `;
  document.body.appendChild(host);
  setTimeout(() => host.remove(), 5e3);
}
console.log("Discerned content script loaded");
