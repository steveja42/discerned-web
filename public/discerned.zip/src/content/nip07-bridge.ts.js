export {};
const _origOpen = window.open.bind(window);
window.open = (url, target, features) => {
  if (document.querySelector("discerned-overlay")) return null;
  return _origOpen(url, target, features);
};
window.addEventListener("message", async (event) => {
  if (event.source !== window) return;
  const type = event.data?.type;
  if (typeof type !== "string" || !type.startsWith("DISCERNED_NIP07_")) return;
  if (type === "DISCERNED_NIP07_CHECK") {
    window.postMessage({
      type: "DISCERNED_NIP07_CHECK_RESPONSE",
      hasNostr: typeof window.nostr !== "undefined"
    }, "*");
    return;
  }
  if (type === "DISCERNED_NIP07_PUBKEY") {
    try {
      const pubkey = await window.nostr.getPublicKey();
      window.postMessage({ type: "DISCERNED_NIP07_PUBKEY_RESPONSE", pubkey }, "*");
    } catch (err) {
      window.postMessage({
        type: "DISCERNED_NIP07_PUBKEY_RESPONSE",
        error: err.message
      }, "*");
    }
    return;
  }
  if (type === "DISCERNED_NIP07_SIGN") {
    try {
      const signed = await window.nostr.signEvent(event.data.event);
      window.postMessage({
        type: "DISCERNED_NIP07_SIGN_RESPONSE",
        id: event.data.id,
        signed
      }, "*");
    } catch (err) {
      window.postMessage({
        type: "DISCERNED_NIP07_SIGN_RESPONSE",
        id: event.data.id,
        error: err.message
      }, "*");
    }
  }
});
