const TRACKING_PARAMS = /* @__PURE__ */ new Set([
  // UTM (Universal / Google Analytics)
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_term",
  "utm_content",
  "utm_id",
  "utm_source_platform",
  "utm_creative_format",
  "utm_marketing_tactic",
  // Google Ads
  "gclid",
  "gclsrc",
  "dclid",
  "gbraid",
  "wbraid",
  // Microsoft / Bing Ads
  "msclkid",
  // Meta / Facebook
  "fbclid",
  "fb_action_ids",
  "fb_action_types",
  "fb_source",
  // Twitter / X
  "twclid",
  // Instagram
  "igshid",
  // TikTok
  "ttclid",
  // HubSpot
  "_hsenc",
  "_hsmi",
  "hsctaTracking",
  // Mailchimp
  "mc_cid",
  "mc_eid",
  // Adobe / Omniture
  "s_kwcid",
  "ef_id",
  // Yandex
  "yclid",
  "_openstat",
  // Pinterest
  "epik",
  // LinkedIn
  "li_fat_id",
  // Reddit
  "rdt_cid",
  // Snapchat
  "ScCid",
  // Klaviyo
  "_kx",
  // Drip
  "__s"
]);
export function stripTrackingParams(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return rawUrl;
  }
  const before = parsed.search;
  for (const key of [...parsed.searchParams.keys()]) {
    if (TRACKING_PARAMS.has(key.toLowerCase()) || TRACKING_PARAMS.has(key)) {
      parsed.searchParams.delete(key);
    }
  }
  return before === parsed.search ? rawUrl : parsed.toString();
}
export function captureContext() {
  const selection = window.getSelection();
  const selectedText = selection?.toString().trim();
  if (selectedText && selectedText.length > 0) {
    return captureQuote(selection);
  }
  return captureResource();
}
function captureQuote(selection) {
  const range = selection.getRangeAt(0);
  const container = range.cloneContents();
  const sanitized = sanitizeHTML(container);
  const context = extractContext(range);
  return {
    type: "quote",
    content: sanitized,
    url: stripTrackingParams(window.location.href),
    context,
    timestamp: Date.now()
  };
}
function captureResource() {
  const title = document.title || "Untitled Page";
  const url = stripTrackingParams(window.location.href);
  const ogImage = document.querySelector('meta[property="og:image"]')?.content;
  const firstImg = document.querySelector("img")?.src;
  const thumbnail = ogImage || firstImg || null;
  return {
    type: "resource",
    title,
    url,
    thumbnail,
    timestamp: Date.now()
  };
}
function sanitizeHTML(fragment) {
  const ALLOWED_TAGS = /* @__PURE__ */ new Set(["b", "i", "a", "p", "br", "strong", "em", "span"]);
  const ALLOWED_ATTRS = /* @__PURE__ */ new Set(["href", "style"]);
  const div = document.createElement("div");
  div.appendChild(fragment.cloneNode(true));
  div.querySelectorAll("script, style, iframe, object, embed").forEach((el) => el.remove());
  const walk = (node) => {
    Array.from(node.childNodes).forEach(walk);
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const element = node;
    const tagName = element.tagName.toLowerCase();
    if (!ALLOWED_TAGS.has(tagName)) {
      element.replaceWith(...Array.from(element.childNodes));
      return;
    }
    Array.from(element.attributes).forEach((attr) => {
      if (!ALLOWED_ATTRS.has(attr.name)) {
        element.removeAttribute(attr.name);
      }
    });
    const styleVal = element.getAttribute("style");
    if (styleVal !== null) {
      const safe = styleVal.replace(/expression\s*\(/gi, "").replace(/javascript\s*:/gi, "").replace(/url\s*\(/gi, "").replace(/-moz-binding/gi, "").replace(/behavior\s*:/gi, "");
      if (safe.trim()) {
        element.setAttribute("style", safe);
      } else {
        element.removeAttribute("style");
      }
    }
  };
  Array.from(div.childNodes).forEach(walk);
  return div.innerHTML.trim();
}
function extractContext(range) {
  const CONTEXT_LENGTH = 100;
  try {
    const startContainer = range.startContainer;
    const textContent = startContainer.textContent || "";
    const startOffset = range.startOffset;
    const before = textContent.substring(
      Math.max(0, startOffset - CONTEXT_LENGTH),
      startOffset
    ).trim();
    const after = textContent.substring(
      range.endOffset,
      Math.min(textContent.length, range.endOffset + CONTEXT_LENGTH)
    ).trim();
    return `...${before} [...] ${after}...`;
  } catch (error) {
    console.warn("Could not extract context:", error);
    return "";
  }
}
export function isCapturablePage() {
  const url = window.location.href;
  if (url.startsWith("chrome://") || url.startsWith("chrome-extension://")) {
    return false;
  }
  if (url.startsWith("file://")) {
    return false;
  }
  return true;
}
