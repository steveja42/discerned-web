(function () {
  'use strict';

  const injectTime = performance.now();
  (async () => {
    console.warn("./nip07-bridge.ts.js", "Content-script doesn't support HMR because the world is MAIN");
    const { onExecute } = await import(
      /* @vite-ignore */
      "./nip07-bridge.ts.js"
    );
    onExecute?.({ perf: { injectTime, loadTime: performance.now() - injectTime } });
  })().catch(console.error);

})();
